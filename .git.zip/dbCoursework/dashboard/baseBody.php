<div class="container-fluid">
  <div class="row">
    <div class="col-sm-3 col-md-2 sidebar">
      <h2> Account </h2>
      <ul class="nav nav-sidebar">
        <li class="active"><a href="#">Dashboard <span class="sr-only">(current)</span></a></li>
        <li><a href="#">My current bids</a></li>
        <li><a href="#">History</a></li>
        <li><a href="#">Messages</a></li>
      </ul>
      <br>
      <h2> Shopping </h2>
      <ul class="nav nav-sidebar">
        <li><a href="">Search item</a></li>
        <li><a href="">Categories</a></li>
        <li><a href="">Vendors</a></li>
        <li><a href="">Another nav item</a></li>
        <li><a href="">More navigation</a></li>
      </ul>
      <br>
      <h2> Extra </h2>
      <ul class="nav nav-sidebar">
        <li><a href="">Nav item again</a></li>
        <li><a href="">One more nav</a></li>
        <li><a href="">Another nav item</a></li>
      </ul>
    </div>
    </div>
</div>
