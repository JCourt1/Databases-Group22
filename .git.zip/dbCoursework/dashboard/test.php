<?php include('baseHead.php'); ?>

<body>

  <?php include('baseHeader.php'); ?>

  <?php include('baseBody.php'); ?>

</body>

<?php include('baseFooter.php'); ?>
