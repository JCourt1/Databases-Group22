<html>

<?php include("../dashboard/baseHead.php"); ?>


    <body>

        <?php include("../dashboard/baseHeader.php"); ?>
        <?php include("../dashboard/baseBody.php"); ?>

    </body>

        <?php include("../dashboard/baseFooter.php"); ?>

</html>
